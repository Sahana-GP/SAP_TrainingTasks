/*
 * Copyright (c) 2019 SAP SE or an SAP affiliate company. All rights reserved.
 */
package org.myshoestore.core.jalo;

/**
 * Style variant of apparel product.
 */
public class ApparelStyleVariantProduct extends GeneratedApparelStyleVariantProduct
{
	// Deliberately empty class
}
