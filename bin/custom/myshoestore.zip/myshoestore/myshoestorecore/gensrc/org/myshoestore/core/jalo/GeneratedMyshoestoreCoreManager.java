/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 11-Dec-2022, 7:27:51 PM                     ---
 * ----------------------------------------------------------------
 */
package org.myshoestore.core.jalo;

import de.hybris.platform.deeplink.jalo.media.BarcodeMedia;
import de.hybris.platform.jalo.GenericItem;
import de.hybris.platform.jalo.Item;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.JaloBusinessException;
import de.hybris.platform.jalo.JaloInvalidParameterException;
import de.hybris.platform.jalo.JaloSystemException;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.c2l.C2LManager;
import de.hybris.platform.jalo.c2l.Language;
import de.hybris.platform.jalo.extension.Extension;
import de.hybris.platform.jalo.product.Product;
import de.hybris.platform.jalo.type.ComposedType;
import de.hybris.platform.jalo.type.JaloGenericCreationException;
import de.hybris.platform.jalo.user.Customer;
import de.hybris.platform.jalo.user.User;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import org.myshoestore.core.constants.MyshoestoreCoreConstants;
import org.myshoestore.core.jalo.ApparelProduct;
import org.myshoestore.core.jalo.ApparelSizeVariantProduct;
import org.myshoestore.core.jalo.ApparelStyleVariantProduct;
import org.myshoestore.core.jalo.ElectronicsColorVariantProduct;

/**
 * Generated class for type <code>MyshoestoreCoreManager</code>.
 */
@SuppressWarnings({"deprecation","unused","cast"})
public abstract class GeneratedMyshoestoreCoreManager extends Extension
{
	protected static final Map<String, Map<String, AttributeMode>> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, Map<String, AttributeMode>> ttmp = new HashMap();
		Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>();
		tmp.put("productQRCode", AttributeMode.INITIAL);
		ttmp.put("de.hybris.platform.jalo.product.Product", Collections.unmodifiableMap(tmp));
		tmp = new HashMap<String, AttributeMode>();
		tmp.put("loyalityPoints", AttributeMode.INITIAL);
		ttmp.put("de.hybris.platform.jalo.user.Customer", Collections.unmodifiableMap(tmp));
		DEFAULT_INITIAL_ATTRIBUTES = ttmp;
	}
	@Override
	public Map<String, AttributeMode> getDefaultAttributeModes(final Class<? extends Item> itemClass)
	{
		Map<String, AttributeMode> ret = new HashMap<>();
		final Map<String, AttributeMode> attr = DEFAULT_INITIAL_ATTRIBUTES.get(itemClass.getName());
		if (attr != null)
		{
			ret.putAll(attr);
		}
		return ret;
	}
	
	public ApparelProduct createApparelProduct(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( MyshoestoreCoreConstants.TC.APPARELPRODUCT );
			return (ApparelProduct)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating ApparelProduct : "+e.getMessage(), 0 );
		}
	}
	
	public ApparelProduct createApparelProduct(final Map attributeValues)
	{
		return createApparelProduct( getSession().getSessionContext(), attributeValues );
	}
	
	public ApparelSizeVariantProduct createApparelSizeVariantProduct(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( MyshoestoreCoreConstants.TC.APPARELSIZEVARIANTPRODUCT );
			return (ApparelSizeVariantProduct)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating ApparelSizeVariantProduct : "+e.getMessage(), 0 );
		}
	}
	
	public ApparelSizeVariantProduct createApparelSizeVariantProduct(final Map attributeValues)
	{
		return createApparelSizeVariantProduct( getSession().getSessionContext(), attributeValues );
	}
	
	public ApparelStyleVariantProduct createApparelStyleVariantProduct(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( MyshoestoreCoreConstants.TC.APPARELSTYLEVARIANTPRODUCT );
			return (ApparelStyleVariantProduct)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating ApparelStyleVariantProduct : "+e.getMessage(), 0 );
		}
	}
	
	public ApparelStyleVariantProduct createApparelStyleVariantProduct(final Map attributeValues)
	{
		return createApparelStyleVariantProduct( getSession().getSessionContext(), attributeValues );
	}
	
	public ElectronicsColorVariantProduct createElectronicsColorVariantProduct(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( MyshoestoreCoreConstants.TC.ELECTRONICSCOLORVARIANTPRODUCT );
			return (ElectronicsColorVariantProduct)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating ElectronicsColorVariantProduct : "+e.getMessage(), 0 );
		}
	}
	
	public ElectronicsColorVariantProduct createElectronicsColorVariantProduct(final Map attributeValues)
	{
		return createElectronicsColorVariantProduct( getSession().getSessionContext(), attributeValues );
	}
	
	@Override
	public String getName()
	{
		return MyshoestoreCoreConstants.EXTENSIONNAME;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Customer.loyalityPoints</code> attribute.
	 * @return the loyalityPoints - Loyality Points of User
	 */
	public Integer getLoyalityPoints(final SessionContext ctx, final Customer item)
	{
		if( ctx == null || ctx.getLanguage() == null )
		{
			throw new JaloInvalidParameterException("GeneratedCustomer.getLoyalityPoints requires a session language", 0 );
		}
		return (Integer)item.getLocalizedProperty( ctx, MyshoestoreCoreConstants.Attributes.Customer.LOYALITYPOINTS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Customer.loyalityPoints</code> attribute.
	 * @return the loyalityPoints - Loyality Points of User
	 */
	public Integer getLoyalityPoints(final Customer item)
	{
		return getLoyalityPoints( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Customer.loyalityPoints</code> attribute. 
	 * @return the loyalityPoints - Loyality Points of User
	 */
	public int getLoyalityPointsAsPrimitive(final SessionContext ctx, final Customer item)
	{
		Integer value = getLoyalityPoints( ctx,item );
		return value != null ? value.intValue() : 0;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Customer.loyalityPoints</code> attribute. 
	 * @return the loyalityPoints - Loyality Points of User
	 */
	public int getLoyalityPointsAsPrimitive(final Customer item)
	{
		return getLoyalityPointsAsPrimitive( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Customer.loyalityPoints</code> attribute. 
	 * @return the localized loyalityPoints - Loyality Points of User
	 */
	public Map<Language,Integer> getAllLoyalityPoints(final SessionContext ctx, final Customer item)
	{
		return (Map<Language,Integer>)item.getAllLocalizedProperties(ctx,MyshoestoreCoreConstants.Attributes.Customer.LOYALITYPOINTS,C2LManager.getInstance().getAllLanguages());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Customer.loyalityPoints</code> attribute. 
	 * @return the localized loyalityPoints - Loyality Points of User
	 */
	public Map<Language,Integer> getAllLoyalityPoints(final Customer item)
	{
		return getAllLoyalityPoints( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Customer.loyalityPoints</code> attribute. 
	 * @param value the loyalityPoints - Loyality Points of User
	 */
	public void setLoyalityPoints(final SessionContext ctx, final Customer item, final Integer value)
	{
		if ( ctx == null) 
		{
			throw new JaloInvalidParameterException( "ctx is null", 0 );
		}
		if( ctx.getLanguage() == null )
		{
			throw new JaloInvalidParameterException("GeneratedCustomer.setLoyalityPoints requires a session language", 0 );
		}
		item.setLocalizedProperty(ctx, MyshoestoreCoreConstants.Attributes.Customer.LOYALITYPOINTS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Customer.loyalityPoints</code> attribute. 
	 * @param value the loyalityPoints - Loyality Points of User
	 */
	public void setLoyalityPoints(final Customer item, final Integer value)
	{
		setLoyalityPoints( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Customer.loyalityPoints</code> attribute. 
	 * @param value the loyalityPoints - Loyality Points of User
	 */
	public void setLoyalityPoints(final SessionContext ctx, final Customer item, final int value)
	{
		setLoyalityPoints( ctx, item, Integer.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Customer.loyalityPoints</code> attribute. 
	 * @param value the loyalityPoints - Loyality Points of User
	 */
	public void setLoyalityPoints(final Customer item, final int value)
	{
		setLoyalityPoints( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Customer.loyalityPoints</code> attribute. 
	 * @param value the loyalityPoints - Loyality Points of User
	 */
	public void setAllLoyalityPoints(final SessionContext ctx, final Customer item, final Map<Language,Integer> value)
	{
		item.setAllLocalizedProperties(ctx,MyshoestoreCoreConstants.Attributes.Customer.LOYALITYPOINTS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Customer.loyalityPoints</code> attribute. 
	 * @param value the loyalityPoints - Loyality Points of User
	 */
	public void setAllLoyalityPoints(final Customer item, final Map<Language,Integer> value)
	{
		setAllLoyalityPoints( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.productQRCode</code> attribute.
	 * @return the productQRCode
	 */
	public BarcodeMedia getProductQRCode(final SessionContext ctx, final Product item)
	{
		return (BarcodeMedia)item.getProperty( ctx, MyshoestoreCoreConstants.Attributes.Product.PRODUCTQRCODE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.productQRCode</code> attribute.
	 * @return the productQRCode
	 */
	public BarcodeMedia getProductQRCode(final Product item)
	{
		return getProductQRCode( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.productQRCode</code> attribute. 
	 * @param value the productQRCode
	 */
	public void setProductQRCode(final SessionContext ctx, final Product item, final BarcodeMedia value)
	{
		item.setProperty(ctx, MyshoestoreCoreConstants.Attributes.Product.PRODUCTQRCODE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.productQRCode</code> attribute. 
	 * @param value the productQRCode
	 */
	public void setProductQRCode(final Product item, final BarcodeMedia value)
	{
		setProductQRCode( getSession().getSessionContext(), item, value );
	}
	
}
