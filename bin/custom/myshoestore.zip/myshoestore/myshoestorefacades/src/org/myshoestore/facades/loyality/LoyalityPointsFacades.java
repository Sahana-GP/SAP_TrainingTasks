package org.myshoestore.facades.loyality;

import org.myshoestore.facades.LoyalityData;



public interface LoyalityPointsFacades
{
	public LoyalityData defaultLoyalityPointsFacade();
}
