/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 11-Dec-2022, 7:27:51 PM                     ---
 * ----------------------------------------------------------------
 */
package org.myshoestore.facades.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated(since = "ages", forRemoval = false)
@SuppressWarnings({"unused","cast"})
public class GeneratedMyshoestoreFacadesConstants
{
	public static final String EXTENSIONNAME = "myshoestorefacades";
	
	protected GeneratedMyshoestoreFacadesConstants()
	{
		// private constructor
	}
	
	
}
